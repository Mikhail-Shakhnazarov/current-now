from __future__ import annotations

import json
import os
import sys
import time
from typing import Any, Dict

"""Dummy long-lived engine for Atlas TUI v2.

Reads JSONL from stdin and writes JSONL to stdout.

Protocol:
- submit: {"type":"submit","id":"...","payload": EngineInput}
- result: {"type":"result","id":"...","ok":true,"payload": EngineOutput}
"""

def _emit(obj: Dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()

def _assemble_system(payload: Dict[str, Any]) -> str:
    mode = payload.get("mode", "interpret")
    ws = payload.get("workspace", {})
    repo_root = ws.get("repo_root", "")
    project_root = ws.get("project_root")

    # Deterministic, inspectable "system" scaffold. Real engine will replace this.
    parts = [
        f"Atlas Engine (dummy) — assembled context",
        f"mode: {mode}",
        f"repo_root: {repo_root}",
        f"project_root: {project_root or 'None'}",
        "",
        "Rules:",
        "- This is a dummy engine. No provider calls are performed.",
        "- The TUI must treat this system string as opaque and only preview it.",
        "",
        "Selected artifacts (dummy):",
        "- (none)",
    ]
    return "\n".join(parts)

def main() -> int:
    # Optional startup event
    _emit({"type": "event", "level": "info", "message": "dummy engine started", "ts": time.time()})

    for raw in sys.stdin:
        line = raw.strip()
        if not line:
            continue
        try:
            msg = json.loads(line)
        except json.JSONDecodeError:
            _emit({"type":"event","level":"error","message":"received non-JSON input", "ts": time.time(), "data":{"line": line[:200]}})
            continue

        if msg.get("type") != "submit":
            continue

        req_id = msg.get("id")
        payload = msg.get("payload") or {}
        if not req_id:
            continue

        try:
            user_message = payload.get("user_message", "")
            mode = payload.get("mode", "interpret")
            provider = payload.get("provider", "openai")
            model = payload.get("model", "unknown")

            system = _assemble_system(payload)
            # Provider request is what *would* be sent; in real engine this could be structured messages.
            provider_request = {
                "provider": provider,
                "model": model,
                "system": system,
                "user": user_message,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": user_message},
                ],
            }

            out = {
                "assembled_context": {"mode": mode, "system": system},
                "provider_request": provider_request,
                "diagnostics": {
                    "sizes": {
                        "system_chars": len(system),
                        "user_chars": len(user_message),
                    },
                    "selected_artifacts": [],
                    "timings_ms": {"assemble": 1},
                },
            }

            _emit({"type": "result", "id": req_id, "ok": True, "payload": out})
        except Exception as e:
            _emit({"type": "result", "id": req_id, "ok": False, "error": {"code": "exception", "message": str(e), "details": {}}})

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
