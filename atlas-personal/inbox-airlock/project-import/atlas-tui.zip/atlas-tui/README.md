# Atlas TUI (v2) — Textual cockpit + engine inspection

This is a thin terminal UI layer for Atlas TUI v2. It does **not** call provider APIs.
Instead, it calls a **long-lived engine child process** over a JSONL protocol to
receive `EngineOutput` (assembled context + provider request + diagnostics), then
writes deterministic inspection logs to disk.

## Install (dev)

```bash
cd atlas-tui
python -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Run

From anywhere inside a git repo:

```bash
atlas-tui
```

By default, Atlas TUI launches a bundled dummy engine:

- `python -m atlas_tui.dummy_engine`

To use a real engine:

```bash
ATLAS_ENGINE_CMD="python -m atlas_engine" atlas-tui
# or
atlas-tui --engine-cmd "python -m atlas_engine"
```

## Logs

On each submit, an inspection log is written to:

- If wrapper exists: `project_root/logs/atlas-tui/assembled/`
- Else: `repo_root/.atlas-tui/logs/assembled/`

Chat transcript logging can be toggled in-app (Ctrl+L); logs go to `.../logs/chat/`.

## License

MIT — see LICENSE.
